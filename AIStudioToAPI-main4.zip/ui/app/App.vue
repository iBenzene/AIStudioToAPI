<!--
 * File: ui/app/App.vue
 * Description: Root Vue component that serves as the main entry point for the application router
 *
 * Maintainers: iBenzene, bbbugg
 * Original Author: Ellinav
-->

<template>
    <router-view />
</template>
